
% Stationary GPS receiver 
% (c) Bj?rn ?strand, 2012
close all; clear all; 

DATA = load('gps_ex1_window2012.txt');
Longitude = DATA(:,4); % read all rows in column 4
Latitude  = DATA(:,3); % read all rows in column 3
figure, plot(Longitude,Latitude);
title('Position in NMEA-0183 format');
xlabel('Longitude');
ylabel('Latitude');

%% 3.1 Write a function that transform your longitude and latitude angles 
% from NMEA-0183 into meters
% 1. longitude and latitude angles from NMEA-0183 into degrees  

LongDeg = floor(Longitude/100) + (Longitude - floor(Longitude/100)*100)/60;
LatDeg = floor(Latitude/100) + (Latitude - floor(Latitude/100)*100)/60; 

figure, plot(LongDeg,LatDeg, 'r');
title('Position in degrees');
xlabel('Longitude');
ylabel('Latitude');

% 2. longitude and latitude angles from degrees into meters
a = 6378137;
b = 6356742.3142;
h = 0;
F_lon = 62393; % from table
F_lat = 111342; % from table

X = F_lon * LongDeg;
Y = F_lat * LatDeg;

figure, plot(X,Y,'g');
title('Position in meters');
xlabel('X in meters');
ylabel('Y in meters');

%% 3.2 Estimate the mean and variance of the position (in x and y)
% Matlab fuctions mean() and var()
% -> Your code here
mean_x = mean(X);
mean_y = mean(Y);
var_x = var(X);
var_y = var(Y);
error_x = X-mean_x;
error_y = Y-mean_y;
% figure, plot(X, Y, '.'), hold, plot(mean_x, mean_y, 'or')
% title("Position in meters and center point of the dataset")
% xlabel("X (m)"), ylabel("Y (m)"), legend("Dataset", "Center point")
% figure, plot(error_x(1:10), error_y(1:10), 'x'), title('Initial few points of mean error');
% figure, plot(error_x(end-10:end), error_y(end-10:end), 'x'), title('Last few points of mean error');
EMax_x = max(abs(min(error_x)), max(error_x));
EMax_y = max(abs(min(error_y)), max(error_y));
maxE = max(error_y);
figure, plot(error_x, error_y, '.'), hold, plot(error_x(error_y == maxE), maxE, 'Xr'); 
title('Relation between mean erorr Y and mean error X, max error point'), xlabel("Error of X"), ylabel("Error of Y")
legend("Error", "Maximum error")
figure
plot(error_x, error_y, 'x');
plot_uncertainty([0 0]', cov(error_x, error_y), 1, 2);
title('Relation between mean erorr Y and mean error X, covariance');
legend('Mean Error', 'Covariance'), xlabel("Error of X"), ylabel("Error of Y")
figure, plot(X, Y), hold, plot(X(1:2:50), Y(1:2:50), 'rx')
title("Initial points"), xlabel("X in meters"), ylabel("Y in meters")
legend("Dataset", "Initial points")
figure
subplot(2, 1, 1), histogram(error_x,30), title('Histogram of errors in X');
subplot(2, 1, 2), histogram(error_y,30), title('Histogram of errors in Y');

%% 3.3 Plot, with respect to time, the errors and the auto-correlation 
% in x and y separately.
% -> Your code here
figure
subplot(4, 1, 1), plot(error_x), title('Error X respect to time');
subplot(4, 1, 2), plot(error_y), title('Error Y respect to time');
cx = xcorr(error_x, 'coeff');
cy = xcorr(error_y, 'coeff');
RN = randn(1, length(X));
cn = xcorr(RN, 'coeff');
subplot(4, 1, 3), plot(cx), hold, plot(cn), title('Auto-Correlation'), legend('Error X', 'Random variable');
subplot(4, 1, 4), plot(cy), hold, plot(cn), title('Auto-Correlation'), legend('Error Y', 'Random variable');

% Make a new script for section 4 and onward using this script as template
