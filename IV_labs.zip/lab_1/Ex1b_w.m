close all; clear all; 

% Load data
DATA = load('gps_ex1_morningdrive2012.txt');
Longitude = DATA(:,4); % read all rows in column 4
Latitude  = DATA(:,3); % read all rows in column 3
figure, plot(Longitude,Latitude);
title('Position in NMEA-0183 format');
xlabel('Longitude'), ylabel('Latitude');

% Transform angles NMEA-0183 into meters 
% 1. longitude and latitude angles from NMEA-0183 into degrees  

LongDeg = floor(Longitude/100) + (Longitude - floor(Longitude/100)*100)/60;
LatDeg = floor(Latitude/100) + (Latitude - floor(Latitude/100)*100)/60; 

figure, plot(LongDeg,LatDeg, 'r');
title('Position in degrees');
xlabel('Longitude (deg)');
ylabel('Latitude (deg)');

% 2. longitude and latitude angles from degrees into meters
F_lon = 62393; % from table
F_lat = 111342; % from table

X = F_lon * LongDeg;
Y = F_lat * LatDeg;

figure, plot(X,Y,'g')
title('Position in meters'), xlabel('X in meters'), ylabel('Y in meters');

% figure
% x_lim = [8.028, 8.04].*(10^5);
% y_lim = [6.3088, 6.3106].*(10^6);
% Im = imread('halmstad_drive_area.gif');
% image('CData',Im', 'XData', x_lim, 'Ydata',y_lim)
% hold on
% plot(X,Y, 'linewidth',3)
% title('Position in meters'), xlabel('X position (m)'), ylabel('Y position (m)');
% hold off





%% Maximum speed taken
time_ = DATA(:,2);

distance = zeros(length(X),1);
for i = 2:length(X)
    distance(i) = ((X(i) - X(i-1)).^2 + (Y(i) - Y(i-1)).^2).^(1/2);
end

speed = zeros(length(X),1);
for i = 2:length(X)
    speed(i) = distance(i)/(time_(i) - time_(i-1));
end
% figure, plot(distance)
% title("Distance travelled"), xlabel("Time"), ylabel("Distance (m)")

sev = 70.*ones(length(X),1);
ms = max(speed);
figure, plot(speed*3.6), hold, plot(sev), plot(find(speed == ms), ms*3.6, 'X')
title("Instant speed of vehicle"), xlabel("Time"), ylabel("Speed (km/h)")
legend("Instant Speed", "70 km/h", "Maximum speed ("+string(floor(ms*3.6))+" km/h)")

%% Heading
heading = zeros(length(X), 1);
for i = 1:length(X)
    heading(i) = 180/pi*atan2(Y(i), X(i));
end

heading_norm = (heading - mean(heading))/var(heading);
figure, plot(heading)
title("Heading along the path"), xlabel("Time"), ylabel("Heading (deg)")
% Laholms: X[802833, 803908] Y[6309840, 6309000]; Vrangelsleden: X[803578, 803980] Y[6310100, 6309040]
laholm = zeros(10, 4);
cc = 1;
dc = 1;
cond = 0;
for i = 1:length(X)
    if X(i) > 802833.0 && X(i) < 803908 && Y(i) > 6309000 && Y(i) < 6309825
        cond = 1;
        laholm(cc, 1) = X(i);
        laholm(cc, 2) = Y(i);
        laholm(cc, 3) = heading(i);
        laholm(cc, 4) = time_(i);
        cc = cc +1;
    else
        dc = dc +1;
    end
    if dc > 270 && cond == 1
        break
    end
end
figure, plot(X, Y, '.'), hold, plot(laholm(:,1), laholm(:,2), '.')
title("Laholmsvagen path"), xlabel("X (m)"), ylabel("Y (m)"), legend("Path", "Laholmsvagen")
figure, plot(laholm(:,4)-time_(1),laholm(:,3)), title("Laholmsvagen heading"), xlabel("Time"), ylabel("Heading (deg)")

mean_LH = mean(laholm(:,3));
var_LH = var(laholm(:,3));

% ignoring the values near 0
LH_new = zeros(10, 1);
cc1 = 1;
for i = 1:length(laholm(:,3))
    if laholm(i,3) > 110 
        LH_new(cc1) = laholm(i,3);
        cc1 = cc1 +1;
    end
end


figure, plot(laholm(:,3)-mean_LH), title("Laholmsvagen error of heading"), xlabel("Time"), ylabel("Heading (deg)")