%
% Main script that reads controller data and laser data
%
clear all;
close all;

% Co-ordinates of the ref. nodes
REF = [1920 9470;   % 01
       10012 8179;  % 02
       9770 7590;   % 03
       11405 7228;  % 04
       11275 6451;  % 05
       11628 6384.5;% 06
       11438 4948;  % 07
       8140 8274;   % 08
       8392 8486;   % 09
       3280 2750;   % 10
       7250 2085;   % 11
       9990 1620;   % 12
       7485 3225;   % 13
       9505 3893;   % 14
       9602 4278;   % 15
       10412 4150;  % 16
       4090 7920;   % 17
       8010 5290;   % 18
       8255 6099;   % 19
       7733 6151;   % 20
       7490 6136;   % 21
       7061 5420;   % 22
       7634 5342];  % 23

% LINE SEGMENT MODEL (Indeces in the REF-vector)
LINES = [1 8;       % L01
         9 2;       % L02
         2 3;       % L03
         3 4;       % L04
         4 5;       % L05
         5 6;       % L06
         6 7;       % L07
         17 10;     % L08
         10 12;     % L09
         11 13;     % L10
         12 16;     % L11
         16 15;     % L12
         15 14;     % L13
         19 21;     % L14
         22 18;     % L15
         20 23];    % L16
         
% Control inputs (velocity and steering angle)
CONTROL = load('control_joy.txt');

% Laser data
LD_HEAD   = load('laser_header.txt');
LD_ANGLES = load('laser_angles.txt');
LD_MEASUR = load('laser_measurements.txt');
LD_FLAGS  = load('laser_flags.txt');

[no_inputs co] = size(CONTROL);

% Robots initial position
X(1) = CONTROL(1,4);
Y(1) = CONTROL(1,5);
A(1) = CONTROL(1,6);

scan_idx = 1;
fig_path = figure;
fig_env = figure;

P(1,1:9) = [1 0 0 0 1 0 0 0 (pi/180)^2];

% Plot the line model
figure(fig_env); plot_line_segments(REF, LINES, 1);
     
for kk = 2:no_inputs,
    % Check if we should get a position fix, i.e. if the time stamp of the
    % next laser scan is the same as the time stamp of the control input
    % values
    old_CXK = [P(kk-1,1:3); P(kk-1, 4:6); P(kk-1, 7:9)];
    if LD_HEAD(scan_idx,1) == CONTROL(kk,1),
        % Mark the position where the position fix is done - and the size
        % of the position fix to be found
        figure(fig_path);
        hold on; plot(X(kk-1), Y(kk-1), 'ro'); hold off;
        hold on; plot(CONTROL(kk-1,4), CONTROL(kk-1,5), 'ro'); hold off;
        hold on; plot([X(kk-1) CONTROL(kk-1,4)], [Y(kk-1) CONTROL(kk-1,5)], 'r'); hold off;
        
        % Get the position fix - Use data points that are ok, i.e. with
        % flags = 0
        DATAPOINTS = find(LD_FLAGS(scan_idx,:) == 0);
        angs = LD_ANGLES(scan_idx, DATAPOINTS);
        meas = LD_MEASUR(scan_idx, DATAPOINTS);
        
        % Plot schematic picture of the Snowhite robot
        alfa = 660;
        beta = 0;
        gamma = -90*pi/180;
        figure(fig_env); plot_line_segments(REF, LINES, 1);
        plot_threewheeled_Laser([X(kk-1) Y(kk-1) A(kk-1)]', 100, 612, 2, CONTROL(kk-1,5), 150, 50, 680, alfa, beta, gamma, angs, meas, 1);
        
        LINEMODEL = [REF(LINES(:,1),1:2) REF(LINES(:,2),1:2)];
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% from here I have submitted %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % YOU SHOULD WRITE YOUR CODE HERE ....
        % Call the function [dx dy da C] = Cox_LineFit(angs, meas, [X(kk-1) Y(kk-1)
        % A(kk-1)]', LINEMODEL) => Position fix + Unceratinty of the
        % position fix
        [dx, dy, da, C] = Cox_LineFit(angs, meas, [X(kk-1) Y(kk-1) A(kk-1)]', alfa, beta, gamma, LINEMODEL);
        % ... AND HERE ...
        % Update the position, i.e. X(kk-1), Y(kk-1), A(kk-1) and C(kk-1)
        
         X(kk-1) = X(kk-1)+dx;
         Y(kk-1) = Y(kk-1)+dy;
         A(kk-1)= mod(A(kk-1)+da, 2*pi);
         old_CXK = C;     

        %startinig kalman
        
        xpf = CONTROL(kk,4) + randn(1);
        ypf = CONTROL(kk,5) + randn(1);
        apf = CONTROL(kk,6) + randn(1);
        
        cxpf = X(kk-1) + dx;
        cypf = Y(kk-1) + dy;
        capf = A(kk-1) + da;
        
        covar = [100 0 0;
                 0 100 0;
                 0 0 pi/180];
             
        covar1 = [10000 0 0;
                  0 10000 0;
                  0 0 9*pi/180];
              
%         rpe = covar*(inv(covar+old_CXK))*[X(kk-1); Y(kk-1); A(kk-1)]+old_CXK*(inv(covar+old_CXK))*[xpf; ypf; apf];
%         rpeii = inv(inv(covar)+inv(old_CXK));
        
%         rpe = covar1*(inv(covar1+old_CXK))*[X(kk-1); Y(kk-1); A(kk-1)]+old_CXK*(inv(covar1+old_CXK))*[xpf; ypf; apf];
%         rpeii = inv(inv(covar1)+inv(old_CXK));
        
%         rpe = C*(inv(C+old_CXK))*[X(kk-1); Y(kk-1); A(kk-1)]+old_CXK*(inv(C+old_CXK))*[cxpf; cypf; capf];
%         rpeii = inv(inv(C)+inv(old_CXK));
%         
%          X(kk-1) = rpe(1);
%          Y(kk-1) = rpe(2);
%          A(kk-1) = mod(rpe(3), 2*pi);
%          old_CXK = rpeii;
        
        % Next time use the next scan
        scan_idx = mod(scan_idx, max(size(LD_HEAD))) + 1;
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% until here I submitted %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        
    end;
    
    % Mark the estimated (dead reckoning) position
    figure(fig_path);
    hold on; plot(X(kk-1), Y(kk-1), 'b.'); hold off;
    % Mark the true (from the LaserWay system) position
    hold on; plot(CONTROL(kk-1,4), CONTROL(kk-1,5), 'k.'); hold off;
    
    % Estimate the new position (based on the control inputs) and new
    % uncertainty
    v = CONTROL(kk-1,2);
    a = CONTROL(kk-1,3);
    T = 0.050;
    L = 680;

    X(kk) = X(kk-1) + cos(a)*v*cos(A(kk-1))*T;
    Y(kk) = Y(kk-1) + cos(a)*v*sin(A(kk-1))*T;
    A(kk) = A(kk-1) + sin(a)*v*T/L;
    
    % ALSO UPDATE THE UNCERTAINTY OF THE POSITION
    CvaT = [0.04*abs(v)       0           0;
            0           var(CONTROL(1:kk,3))       0;
            0           0       0.04*abs(T)];
    
    JXK = [1    0   -T*v*sin(A(kk-1))*cos(a);
           0    1   T*v*cos(A(kk-1))*cos(a);
           0    0   1];
    
    JvaT = [T*cos(A(kk-1))*cos(a), -T*v*cos(A(kk-1))*sin(a), v*cos(A(kk-1))*cos(a);
            T*sin(A(kk-1))*cos(a), -T*v*sin(A(kk-1))*sin(a), v*sin(A(kk-1))*cos(a);
            (T*sin(a))/L,           (T*v*cos(a))/L,             (v*sin(a))/L];
    
    % %uncertanity with odometery
    new_CXK = JXK*old_CXK*JXK' + JvaT*CvaT*JvaT';
    
    P(kk,1:9) = [new_CXK(1,1:3) new_CXK(2,1:3) new_CXK(3,1:3)];
    
end;

ERROR = [X' Y' A'] - CONTROL(:,4:6);
ERROR(:,3) = AngDifference(A',CONTROL(:,6));
ERROR = abs(ERROR);
figure,
subplot(3,1,1);
plot(ERROR(:,1),'b'); hold;
plot(sqrt(P(:,1)),'r'); % one sigma
%plot(ScanPosIndx,sqrt(P(ScanPosIndx,1)),'k.'); % one sigma
title('Error X [mm] and uncertainty [std] (red)');
subplot(3,1,2);
plot(ERROR(:,2),'b'); hold;
plot(sqrt(P(:,5)),'r'); % one sigma
title('Error Y [mm] and uncertainty [std] (red)');
subplot(3,1,3);
plot(ERROR(:,3)*180/pi,'b'); hold;
plot(sqrt(P(:,9))*180/pi,'r'); % one sigma
title('Error A [degree] and uncertainty [std] (red)');




function [dx, dy, da, C] = Cox_LineFit(angs, meas, rposition, alfa, beta, gamma, linemodel )

    
    r = [0 -1;1 0];
    %step 0
    uv = zeros(length(linemodel),2);
    ri = zeros(length(linemodel),1);
    %unit vector
    for i = 1:length(linemodel),
        d = [linemodel(i,3)-linemodel(i,1) linemodel(i,4)-linemodel(i,2)];
        dr = r*d';
        uv(i,:) = dr/norm([d(1), d(2)]);
        ri(i) = dot(uv(i,:),[linemodel(i,3) linemodel(i,4)]);
    end

    ddx = 0;
    ddy = 0;
    dda = 0;
    B = zeros(3,1);
    for musibat = 1:30
        xxr = rposition(1) + ddx;
        yyr = rposition(2) + ddy;
        aar = rposition(3) + dda;
        r = [0 -1;1 0];

        laserx = meas.*cos(angs);
        lasery = meas.*sin(angs);

        R = [cos(gamma) -sin(gamma) alfa; sin(gamma) cos(gamma) beta; 0 0 1];
        sc = [laserx' lasery' ones(length(laserx),1)];
        Xs = R*sc';


        RR = [cos(aar) -sin(aar) xxr; sin(aar) cos(aar) yyr; 0 0 1];
        rc = [Xs(1,:)' Xs(2,:)' ones(length(Xs),1)];
        Xw = RR*rc';
        % ... AND HERE ...
        exx = uv*Xw(1:2,:);
        yi = ri - exx;
        sqrdyi = (yi).^2;
        minyi = min(sqrdyi);
        myindex = minyi == sqrdyi;
        %outliers

        medyi = median(minyi);
        lessyi = sqrdyi < medyi;
        myand = myindex & lessyi;
        kept = myand.*sqrdyi;

        [notzerosx, notzerosy] = find(kept ~= 0); 

        vi = Xw(1:2,notzerosy); 
        vm = mean(vi')';

        xione(:,1) = uv(notzerosx,1);
        xitwo(:,1) = uv(notzerosx,2);
        xithree = zeros(length(notzerosx),1);
        ykept = zeros(length(notzerosx),1);
        for p = 1:length(notzerosx)
          xithree(p) =   uv(notzerosx(p),:)*r*(vi(:,p)-vm);
          ykept(p) = yi(notzerosx(p), notzerosy(p));
        end
        A = [xione xitwo xithree];

        B = inv(A'*A)*A'*ykept;
%  
%          figure()
%          hold on;
%          for w = 1:length(linemodel)
%              hold on;
%              plot(linemodel(w,1), 'r');
%          end
%          plot(Xw, 'b');
%          plot(kept, 'g');
%          hold off;
%          figure, hold on,
%          plot(xxr, yyr,'r')
%          plot(Xw(1,:), Xw(2,:),'ro')
%          nn = length(uv);
%          for i = 1:nn
%              plot([linemodel(i,1) linemodel(i,3)], [linemodel(i,2) linemodel(i,4)])
%          end
%          plot(Xw(1,notzerosy), Xw(2,notzerosy),'gx')
%          hold off
        n = max(size(A));
        S2 = ((ykept - A*B)'*(ykept - A*B))/(n - 4);
        C = S2*inv(A'*A);

        ddx = ddx + B(1);
        ddy = ddy + B(2);
        dda = dda + B(3);

        if  (sqrt(B(1)^2 + B(2)^2) < 5 )&&(abs(B(3)) <0.1*pi/180)
            break;
        end
    end
    
    dx = ddx;
    dy = ddy;
    da = dda;
    
    
end
