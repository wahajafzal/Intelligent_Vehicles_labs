%
% Dead Reckoning with Snowhite Mini Robot
%

clear all
close all

data = load('snowhite.txt');

V = data(:,1);      % speed
A = data(:,2);      % alpha
tX = data(:,3);     % true X
disp(tX(1))
tY = data(:,4);     % true Y
tTh = data(:,5);    % true Theta

T = 50*10^-3;       % [ms]
L = 680;            % [mm]
Diameter = 14;      % [mm]
WB = 45;            % [mm]


syms Xk0 Yk0 Th0 v alpha nT

nXYTh = [Xk0 + v*cos(alpha)*nT*cos(Th0 + (v*sin(alpha)*nT)/(2*L));
        Yk0 + v*cos(alpha)*nT*sin(Th0 + (v*sin(alpha)*nT)/(2*L));
        Th0 + v*sin(alpha)*nT/L];
nJXYTh = jacobian(nXYTh, [Xk0, Yk0, Th0]);
nJVAT = jacobian(nXYTh, [v, alpha, nT]);
CVAT = [var(V(325:3803)) 0 0; 0 var(A) 0; 0 0 var(T)];
n = length(V);

X(1) = tX(1);
disp(X)
Y(1) = tY(1); 
Th(1) = tTh(1);

%P(1,1:9) = [1 0 0 0 1 0 0 0 1];
P(1,1:9) = [1 0 0 0 1 0 0 0 (1*pi/180)^2];


disp("Calculating ...")

for kk = 2:n
    X(kk) = X(kk-1) + V(kk)*cos(A(kk))*T*cos(Th(kk-1) + (V(kk)*sin(A(kk))*T)/(2*L));
    Y(kk) = Y(kk-1) + V(kk)*cos(A(kk))*T*sin(Th(kk-1) + (V(kk)*sin(A(kk))*T)/(2*L));
    phi = Th(kk-1) + V(kk)*sin(A(kk))*T/L;
    Th(kk) = mod(phi, 2*pi);
    
    JXYTh = [[1, 0, -T*V(kk)*sin(Th(kk-1) + (T*V(kk)*sin(A(kk)))/2/L)*cos(A(kk))];
            [0, 1,   T*V(kk)*cos(Th(kk-1) + (T*V(kk)*sin(A(kk)))/2/L)*cos(A(kk))];
            [0, 0,                                                  1]];
    
    JVAT = subs(nJVAT, [Xk0, Yk0, Th0, v, alpha, nT], [X(kk-1), Y(kk-1), Th(kk-1), V(kk), A(kk), T]);
    old_CXYTh = [P(kk-1,1:3); P(kk-1,4:6); P(kk-1,7:9)];
    
    new_CXYTh = JXYTh*old_CXYTh*JXYTh' + JVAT*CVAT*JVAT';
    
    P(kk,1:9) = [new_CXYTh(1,1:3) new_CXYTh(2,1:3) new_CXYTh(3,1:3)];
    
end


disp('Plotting ...');
figure, plot(X,Y), hold, plot(tX, tY), legend("Estimation", "True position")
title("Robot position"), xlabel("X [mm]"), ylabel("Y [mm]")
% Plot the path taken by the robot, by plotting the uncertainty in the current position
figure; 
    %plot(X, Y, 'b.');
    title('Path taken by the robot [Wang]');
    xlabel('X [mm] World co-ordinates');
    ylabel('Y [mm] World co-ordinates');
    hold on;
        for kk = 1:5:n
            C = [P(kk,1:3);P(kk,4:6);P(kk,7:9)];
            plot_uncertainty([X(kk) Y(kk) A(kk)]', C, 1, 2);
        end
    hold off;
    axis('equal');

    
 error_x = zeros(n, 1);
 error_y = zeros(n, 1);
 error_th = zeros(n, 1);
 for i=1:n
    error_x(i) = tX(i) - X(i);
    error_y(i) = tY(i) - Y(i);
    error_th(i) = tTh(i) - Th(i);
 end
 figure, plot(error_x, error_y), hold, plot(error_x(1), error_y(1),'rx')
 plot(error_x(end), error_y(end),'r*'), legend('Error', 'Inital point', 'End point')
 title("Error of the position"), xlabel("Error in X [mm]"), ylabel("Error in Y [mm]")
 
    figure;
    subplot(3,1,1); plot(error_x, 'b'); title('Error in X [mm]');
    subplot(3,1,2); plot(error_y, 'b'); title('Error in Y [mm]');
    subplot(3,1,3); plot(error_th*180/pi, 'b'); title('Error in Theta [deg]');


figure;
    subplot(3,1,1); plot(X, 'b'); title('X [mm]');
    subplot(3,1,2); plot(Y, 'b'); title('Y [mm]');
    subplot(3,1,3); plot(Th*180/pi, 'b'); title('Theta [deg]');

% Plot the estimated variances (in X, Y and A) - 1 standard deviation
subplot(3,1,1); hold on;
    plot(X'+sqrt(P(:,1)), 'b:');
    plot(X'-sqrt(P(:,1)), 'b:');
hold off;
subplot(3,1,2); hold on;
    plot(Y'+sqrt(P(:,5)), 'b:');
    plot(Y'-sqrt(P(:,5)), 'b:');
hold off;
subplot(3,1,3); hold on;
    plot((Th'+sqrt(P(:,9)))*180/pi, 'b:');
    plot((Th'-sqrt(P(:,9)))*180/pi, 'b:');
hold off;

figure, hold on

for i=1:20:n
    pos = [X(i), Y(i), Th(i)]';
    plot_threewheeled(pos, Diameter, WB, 15, A(i), Diameter, 15, L)
end
hold off


dis = 0;
for i = 2:n
    dis = dis + sqrt((X(i) - X(i-1))^2 + (Y(i) - Y(i-1))^2);
end
disp("Distance [m]")
disp(dis/1000)
disp("Timing [s]")
disp(n*T)